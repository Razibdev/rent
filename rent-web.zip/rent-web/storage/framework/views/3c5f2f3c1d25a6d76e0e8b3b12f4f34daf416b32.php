<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/lib/datatable/dataTables.bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="animated fadeIn">
            <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Data Table</strong>
                        </div>
                        <div class="card-body">
                            <table id="bootstrap-data-table-subscriber" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Action</th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $subscription; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sub->name); ?></td>
                                    <td><?php echo e($sub->email); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('admin.delete.subscriber', $sub->id)); ?>" method="post"><?php echo csrf_field(); ?>

                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>


            </div>
        </div><!-- .animated -->
    </div><!-- .content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="<?php echo e(asset('admin/assets/js/lib/data-table/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/lib/data-table/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/lib/data-table/dataTables.buttons.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#bootstrap-data-table-subscriber').DataTable();
        } );
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\client-rent\rent-web\resources\views/admin/subscriber/subscriber.blade.php ENDPATH**/ ?>